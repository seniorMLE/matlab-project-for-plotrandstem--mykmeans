# Hierarchical-clustering-Algorithm
matlab code on hierarchical clustering algorithm using single linkage , complete linkage and average linkage algorithm.
